﻿ 
namespace RobotAcademy_WinApp
{
    partial class Form1
    {
        /// <summary>
        /// 필수 디자이너 변수입니다.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 사용 중인 모든 리소스를 정리합니다.
        /// </summary>
        /// <param name="disposing">관리되는 리소스를 삭제해야 하면 true이고, 그렇지 않으면 false입니다.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 디자이너에서 생성한 코드

        /// <summary>
        /// 디자이너 지원에 필요한 메서드입니다. 
        /// 이 메서드의 내용을 코드 편집기로 수정하지 마세요.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tbxSendPC_Arduino = new System.Windows.Forms.TextBox();
            this.btnSendPC_Arduino = new System.Windows.Forms.Button();
            this.btnStart = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rtbxReceivePC_Arduino = new System.Windows.Forms.RichTextBox();
            this.rtbxSendPC_Arduino = new System.Windows.Forms.RichTextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btnClearPC_Arduino = new System.Windows.Forms.Button();
            this.btnMotorStop = new System.Windows.Forms.Button();
            this.btnBackward = new System.Windows.Forms.Button();
            this.btnGPS = new System.Windows.Forms.Button();
            this.btnMotorForward = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.rtbxReceivePC_App = new System.Windows.Forms.RichTextBox();
            this.rtbxSendPC_App = new System.Windows.Forms.RichTextBox();
            this.tbxSendPC_App = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnClearPC_App = new System.Windows.Forms.Button();
            this.btnSendPC_App = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnSelect = new System.Windows.Forms.Button();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label5 = new System.Windows.Forms.Label();
            this.btnTest = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxSendPC_Arduino
            // 
            this.tbxSendPC_Arduino.Location = new System.Drawing.Point(65, 36);
            this.tbxSendPC_Arduino.Name = "tbxSendPC_Arduino";
            this.tbxSendPC_Arduino.Size = new System.Drawing.Size(537, 21);
            this.tbxSendPC_Arduino.TabIndex = 1;
            // 
            // btnSendPC_Arduino
            // 
            this.btnSendPC_Arduino.Location = new System.Drawing.Point(608, 34);
            this.btnSendPC_Arduino.Name = "btnSendPC_Arduino";
            this.btnSendPC_Arduino.Size = new System.Drawing.Size(75, 23);
            this.btnSendPC_Arduino.TabIndex = 2;
            this.btnSendPC_Arduino.Text = "Send";
            this.btnSendPC_Arduino.UseVisualStyleBackColor = true;
            this.btnSendPC_Arduino.Click += new System.EventHandler(this.btnSendPC_Arduino_Click);
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(12, 12);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 3;
            this.btnStart.Text = "Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rtbxReceivePC_Arduino);
            this.groupBox1.Controls.Add(this.rtbxSendPC_Arduino);
            this.groupBox1.Controls.Add(this.tbxSendPC_Arduino);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btnClearPC_Arduino);
            this.groupBox1.Controls.Add(this.btnMotorStop);
            this.groupBox1.Controls.Add(this.btnBackward);
            this.groupBox1.Controls.Add(this.btnGPS);
            this.groupBox1.Controls.Add(this.btnMotorForward);
            this.groupBox1.Controls.Add(this.btnSendPC_Arduino);
            this.groupBox1.Location = new System.Drawing.Point(15, 41);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(773, 199);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "PC-ARDUINO";
            // 
            // rtbxReceivePC_Arduino
            // 
            this.rtbxReceivePC_Arduino.Location = new System.Drawing.Point(65, 130);
            this.rtbxReceivePC_Arduino.Name = "rtbxReceivePC_Arduino";
            this.rtbxReceivePC_Arduino.Size = new System.Drawing.Size(537, 60);
            this.rtbxReceivePC_Arduino.TabIndex = 3;
            this.rtbxReceivePC_Arduino.Text = "";
            // 
            // rtbxSendPC_Arduino
            // 
            this.rtbxSendPC_Arduino.Location = new System.Drawing.Point(65, 63);
            this.rtbxSendPC_Arduino.Name = "rtbxSendPC_Arduino";
            this.rtbxSendPC_Arduino.Size = new System.Drawing.Size(537, 60);
            this.rtbxSendPC_Arduino.TabIndex = 3;
            this.rtbxSendPC_Arduino.Text = "";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 12);
            this.label4.TabIndex = 0;
            this.label4.Text = "Receive";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 12);
            this.label3.TabIndex = 0;
            this.label3.Text = "Send";
            // 
            // btnClearPC_Arduino
            // 
            this.btnClearPC_Arduino.Location = new System.Drawing.Point(690, 34);
            this.btnClearPC_Arduino.Name = "btnClearPC_Arduino";
            this.btnClearPC_Arduino.Size = new System.Drawing.Size(75, 23);
            this.btnClearPC_Arduino.TabIndex = 2;
            this.btnClearPC_Arduino.Text = "Clear";
            this.btnClearPC_Arduino.UseVisualStyleBackColor = true;
            this.btnClearPC_Arduino.Click += new System.EventHandler(this.btnClearPC_Arduino_Click);
            // 
            // btnMotorStop
            // 
            this.btnMotorStop.Location = new System.Drawing.Point(689, 92);
            this.btnMotorStop.Name = "btnMotorStop";
            this.btnMotorStop.Size = new System.Drawing.Size(75, 23);
            this.btnMotorStop.TabIndex = 2;
            this.btnMotorStop.Text = "NoID_Stop";
            this.btnMotorStop.UseVisualStyleBackColor = true;
            this.btnMotorStop.Click += new System.EventHandler(this.btnMotorStop_Click);
            // 
            // btnBackward
            // 
            this.btnBackward.Location = new System.Drawing.Point(689, 63);
            this.btnBackward.Name = "btnBackward";
            this.btnBackward.Size = new System.Drawing.Size(75, 23);
            this.btnBackward.TabIndex = 2;
            this.btnBackward.Text = "Backward";
            this.btnBackward.UseVisualStyleBackColor = true;
            this.btnBackward.Click += new System.EventHandler(this.btnBackward_Click);
            // 
            // btnGPS
            // 
            this.btnGPS.Location = new System.Drawing.Point(608, 92);
            this.btnGPS.Name = "btnGPS";
            this.btnGPS.Size = new System.Drawing.Size(75, 23);
            this.btnGPS.TabIndex = 2;
            this.btnGPS.Text = "GPS";
            this.btnGPS.UseVisualStyleBackColor = true;
            this.btnGPS.Click += new System.EventHandler(this.btnGPS_Click);
            // 
            // btnMotorForward
            // 
            this.btnMotorForward.Location = new System.Drawing.Point(608, 63);
            this.btnMotorForward.Name = "btnMotorForward";
            this.btnMotorForward.Size = new System.Drawing.Size(75, 23);
            this.btnMotorForward.TabIndex = 2;
            this.btnMotorForward.Text = "Forward";
            this.btnMotorForward.UseVisualStyleBackColor = true;
            this.btnMotorForward.Click += new System.EventHandler(this.btnMotorForward_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.rtbxReceivePC_App);
            this.groupBox2.Controls.Add(this.rtbxSendPC_App);
            this.groupBox2.Controls.Add(this.tbxSendPC_App);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.btnClearPC_App);
            this.groupBox2.Controls.Add(this.btnSendPC_App);
            this.groupBox2.Location = new System.Drawing.Point(12, 250);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(773, 199);
            this.groupBox2.TabIndex = 4;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PC-APP";
            // 
            // rtbxReceivePC_App
            // 
            this.rtbxReceivePC_App.Location = new System.Drawing.Point(65, 130);
            this.rtbxReceivePC_App.Name = "rtbxReceivePC_App";
            this.rtbxReceivePC_App.Size = new System.Drawing.Size(700, 60);
            this.rtbxReceivePC_App.TabIndex = 3;
            this.rtbxReceivePC_App.Text = "";
            // 
            // rtbxSendPC_App
            // 
            this.rtbxSendPC_App.Location = new System.Drawing.Point(65, 63);
            this.rtbxSendPC_App.Name = "rtbxSendPC_App";
            this.rtbxSendPC_App.Size = new System.Drawing.Size(700, 60);
            this.rtbxSendPC_App.TabIndex = 3;
            this.rtbxSendPC_App.Text = "";
            // 
            // tbxSendPC_App
            // 
            this.tbxSendPC_App.Location = new System.Drawing.Point(65, 36);
            this.tbxSendPC_App.Name = "tbxSendPC_App";
            this.tbxSendPC_App.Size = new System.Drawing.Size(540, 21);
            this.tbxSendPC_App.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 162);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(50, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Receive";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(6, 83);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 12);
            this.label2.TabIndex = 0;
            this.label2.Text = "Send";
            // 
            // btnClearPC_App
            // 
            this.btnClearPC_App.Location = new System.Drawing.Point(690, 34);
            this.btnClearPC_App.Name = "btnClearPC_App";
            this.btnClearPC_App.Size = new System.Drawing.Size(75, 23);
            this.btnClearPC_App.TabIndex = 2;
            this.btnClearPC_App.Text = "Clear";
            this.btnClearPC_App.UseVisualStyleBackColor = true;
            this.btnClearPC_App.Click += new System.EventHandler(this.btnClearPC_App_Click);
            // 
            // btnSendPC_App
            // 
            this.btnSendPC_App.Location = new System.Drawing.Point(611, 34);
            this.btnSendPC_App.Name = "btnSendPC_App";
            this.btnSendPC_App.Size = new System.Drawing.Size(75, 23);
            this.btnSendPC_App.TabIndex = 2;
            this.btnSendPC_App.Text = "Send";
            this.btnSendPC_App.UseVisualStyleBackColor = true;
            this.btnSendPC_App.Click += new System.EventHandler(this.btnSendPC_App_Click);
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btnUpdate);
            this.groupBox3.Controls.Add(this.btnSelect);
            this.groupBox3.Controls.Add(this.listView1);
            this.groupBox3.Location = new System.Drawing.Point(794, 41);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(584, 190);
            this.groupBox3.TabIndex = 7;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "DATA MANAGEMENT";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(468, 45);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(75, 23);
            this.btnUpdate.TabIndex = 9;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnSelect
            // 
            this.btnSelect.Location = new System.Drawing.Point(468, 20);
            this.btnSelect.Name = "btnSelect";
            this.btnSelect.Size = new System.Drawing.Size(75, 23);
            this.btnSelect.TabIndex = 8;
            this.btnSelect.Text = "Select";
            this.btnSelect.UseVisualStyleBackColor = true;
            this.btnSelect.Click += new System.EventHandler(this.btnSelect_Click);
            // 
            // listView1
            // 
            this.listView1.HideSelection = false;
            this.listView1.Location = new System.Drawing.Point(21, 20);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(441, 154);
            this.listView1.TabIndex = 7;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(93, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(38, 12);
            this.label5.TabIndex = 8;
            this.label5.Text = "label5";
            // 
            // btnTest
            // 
            this.btnTest.Location = new System.Drawing.Point(815, 250);
            this.btnTest.Name = "btnTest";
            this.btnTest.Size = new System.Drawing.Size(75, 23);
            this.btnTest.TabIndex = 3;
            this.btnTest.Text = "Arduino";
            this.btnTest.UseVisualStyleBackColor = true;
            this.btnTest.Click += new System.EventHandler(this.btnTest_Click);
            // 
            // timer2
            // 
            this.timer2.Enabled = true;
            this.timer2.Interval = 1000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1390, 461);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnTest);
            this.Controls.Add(this.btnStart);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbxSendPC_Arduino;
        private System.Windows.Forms.Button btnSendPC_Arduino;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rtbxReceivePC_Arduino;
        private System.Windows.Forms.RichTextBox rtbxSendPC_Arduino;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.RichTextBox rtbxReceivePC_App;
        private System.Windows.Forms.RichTextBox rtbxSendPC_App;
        private System.Windows.Forms.TextBox tbxSendPC_App;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnSendPC_App;
        private System.Windows.Forms.Button btnClearPC_Arduino;
        private System.Windows.Forms.Button btnClearPC_App;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnBackward;
        private System.Windows.Forms.Button btnMotorForward;
        private System.Windows.Forms.Button btnGPS;
        private System.Windows.Forms.Button btnMotorStop;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnSelect;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btnTest;
        private System.Windows.Forms.Timer timer2;
    }
}

