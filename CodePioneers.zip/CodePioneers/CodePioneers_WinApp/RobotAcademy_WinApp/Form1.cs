﻿using System;
using System.Collections;
using System.Net;
using System.Reflection.Emit;
using System.Text;
using System.Windows.Forms;
using uPLibrary.Networking.M2Mqtt;
using uPLibrary.Networking.M2Mqtt.Messages;
using System.Data;
using System.Collections.Generic;
 
namespace RobotAcademy_WinApp
{
    public partial class Form1 : Form
    {
        struct stQueueObject
        {
            public byte select_dev_or_app;
            public uint id;
            public byte sLock;
            public string gpsLat;
            public string gpsLong;
        };        
        private MqttClient client;        
        ArrayList arrGPS = new ArrayList();
        Queue<stQueueObject> use_device_id_q = new Queue<stQueueObject>();
        //string[] strTopicArray = new string[200000];
        //byte[] strQosArray = new byte[200000];
        int nSendGPSIndex = 0;        
        SQLite sqlite;
        bool bIsTest = false;
        string strTestLock = "0";

        public Form1()
        {
            InitializeComponent();
            //폼 닫기 이벤트 선언
            this.FormClosed += Form1_FormClosing;
        }
        /// <summary>
        /// 폼 닫기 이벤트 핸들러 선언
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Form1_FormClosing(object sender, FormClosedEventArgs e)
        {
            if (client != null && client.IsConnected)
            {
                client.Disconnect();
            }
        }
       
        private void Client_MqttMsgPublishReceived(object sender, MqttMsgPublishEventArgs e)
        {
            // 수신된 메시지를 변수에 저장
            string receivedMessage = Encoding.UTF8.GetString(e.Message);
            //int nResult = -1;
            //foreach(string str in strTopicArray)
            {
                // UI 업데이트를 위해 UI 스레드로 전달
                if (e.Topic == "RO_PY_t1_JIAjoa_OUT_D_P")
                {
                    Invoke(new Action(() =>
                    {
                        // Ref. Protocol Excel File
                        // Delimiter = |                        
                        //nResult = str.IndexOf("D", 20, 1);
                        //if (nResult == 20)
                        {
                            // Arduino -> PC (  Device_ID | APP_ID | Lock Sensor | Alarm | GPS_Lat (위도) | GPS_Long (경도)  )
                            string[] words = receivedMessage.Split('|');
                            if (words.Length > 5)
                            {
                                if (string.Equals(words[1], "") == false)
                                {
                                    stQueueObject stqueue = new stQueueObject();
                                    stqueue.select_dev_or_app = 0;
                                    stqueue.id = uint.Parse(words[0]);
                                    stqueue.sLock = byte.Parse(words[2]);
                                    stqueue.gpsLat = words[4];
                                    stqueue.gpsLong = words[5];
                                    use_device_id_q.Enqueue(stqueue);
                                }
                                else
                                {
                                    
                                }
                                rtbxReceivePC_Arduino.AppendText(receivedMessage + "\n");
                                rtbxReceivePC_Arduino.ScrollToCaret();
                            }
                            
                        }
                    }));
                }

                if (e.Topic == "RO_PY_t1_JIAjoa_OUT_A_P")
                {
                    Invoke(new Action(() =>
                    {
                        // Ref. Protocol Excel File
                        // Delimiter = |                        
                        //nResult = str.IndexOf("A", 20, 1);
                        //if (nResult == 20)
                        {
                            // App -> PC (  APP_ID | Rent On Off | DevID  )
                            string[] words = receivedMessage.Split('|');
                            if(words.Length > 2)
                            {
                                string messageToSend = string.Empty;
                                if (words[1] == "1")
                                {
                                    messageToSend = words[2] + "|" + words[0] + "|0|1";

                                    foreach (DataRow row in sqlite.SelectDetail("user", "user_id, user_point", $@"use_device_id = {int.Parse(words[2])} and use_device =1").Tables[0].Rows)
                                    {
                                        string user_id = row["user_id"].ToString();                                        
                                        sqlite.Update("user", $"use_app =1 ", $"user_id ='{user_id}'");
                                    }
                                }
                                else
                                {
                                    messageToSend = words[2] + "|" + words[0] + "|1|0";
                                    foreach (DataRow row in sqlite.SelectDetail("user", "user_id, user_point", $@"use_device_id = {int.Parse(words[2])} and use_device =1").Tables[0].Rows)
                                    {
                                        string user_id = row["user_id"].ToString();
                                        sqlite.Update("user", $"use_app =0 ", $"user_id ='{user_id}'");
                                    }
                                }
                                client.Publish("RO_PY_t1_JIAjoa_OUT_P_D", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                                rtbxSendPC_Arduino.AppendText(messageToSend + "\n");
                                rtbxSendPC_Arduino.ScrollToCaret();
                            }
                            rtbxReceivePC_App.AppendText(receivedMessage + "\n");
                            rtbxReceivePC_App.ScrollToCaret();
                        }
                    }));
                }
            }
        }        
        
        private void btnStart_Click(object sender, EventArgs e)
        {
            // MQTT 브로커 주소
            string BrokerAddress = "broker.mqtt-dashboard.com"; //  각자 사용할 broker 서버를 기입한다.
            client = new MqttClient(BrokerAddress);

            // 메시지 수신 시 이벤트 핸들러 등록
            client.MqttMsgPublishReceived += Client_MqttMsgPublishReceived;

            // 고유한 클라이언트 ID 생성
            string clientId = "COOKIE";

            try
            {
                client.Connect(clientId);
                //연결이 성공하면 Serverconnect에 성공 메세지출력
                if (client.IsConnected) label5.Text = "SERVER " + BrokerAddress + "와 연결 성공!";
            }
            catch (Exception ex)
            {
                //연결이 실패하면 Serverconnect에 실패 메세지, 오류메세지 출력
                label1.Text = "브로커에 연결할 수 없습니다.\n" + ex.Message + "연결 오류";
            }

            //client.Subscribe(strTopicArray, strQosArray);

            client.Subscribe(new string[] { "RO_PY_t1_JIAjoa_OUT_D_P", "RO_PY_t1_JIAjoa_OUT_A_P" }, new byte[] { MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE });
        }

        private void btnSendPC_Arduino_Click(object sender, EventArgs e)
        {
            // 보낼 메시지
            string messageToSend = tbxSendPC_Arduino.Text;
                        
            client.Publish("RO_PY_t1_JIAjoa_OUT_P_D", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

            rtbxSendPC_Arduino.AppendText(messageToSend+"\n");
            rtbxSendPC_Arduino.ScrollToCaret();

            //메세지박스 초기화
            tbxSendPC_Arduino.Text = "";
        }

        private void btnSendPC_App_Click(object sender, EventArgs e)
        {
            // 보낼 메시지
            string messageToSend = tbxSendPC_App.Text;

            client.Publish("RO_PY_t1_JIAjoa_OUT_P_A", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

            rtbxSendPC_App.AppendText(messageToSend+"\n");
            rtbxSendPC_App.ScrollToCaret();

            //메세지박스 초기화
            tbxSendPC_App.Text = "";
        }

        private void btnClearPC_Arduino_Click(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {
                // receivedMessage를 Form label ReceivedText에 표시
                rtbxReceivePC_Arduino.Clear();                
            }));
        }

        private void btnClearPC_App_Click(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {
                // receivedMessage를 Form label ReceivedText에 표시
                rtbxReceivePC_App.Clear();
            }));
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if(client != null)
                if (client.IsConnected)
                {
                    Invoke(new Action(() =>
                    {
                        listViewUpdate();
                        listViewSelect();
                    }));
                }
        }

        private void btnMotorForward_Click(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {
                string messageToSend = "14|junha123|0|1";

                client.Publish("RO_PY_t1_JIAjoa_OUT_P_D", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                rtbxSendPC_Arduino.AppendText(messageToSend + "\n");
                rtbxSendPC_Arduino.ScrollToCaret();
            }));
        }

        private void btnBackward_Click(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {
                string messageToSend = "14|junha123|1|0";

                client.Publish("RO_PY_t1_JIAjoa_OUT_P_D", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                rtbxSendPC_Arduino.AppendText(messageToSend + "\n");
                rtbxSendPC_Arduino.ScrollToCaret();
            }));
        }

        private void btnGPS_Click(object sender, EventArgs e)
        {
            
            Invoke(new Action(() =>
            {
                string messageToSend = "";
                if(nSendGPSIndex < arrGPS.Count)
                {
                    messageToSend = (string)arrGPS[nSendGPSIndex];
                    nSendGPSIndex++;
                }
                else
                {
                    nSendGPSIndex = 0;
                    messageToSend = (string)arrGPS[nSendGPSIndex];
                    nSendGPSIndex++;
                }

                client.Publish("RO_PY_t1_JIAjoa_OUT_P_D", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                rtbxSendPC_Arduino.AppendText(messageToSend + "\n");
                rtbxSendPC_Arduino.ScrollToCaret();
            }));
        }

        void listViewSelect()
        {
            listView1.Items.Clear();
            listView1.BeginUpdate();
            foreach (DataRow row in sqlite.SelectAll("user").Tables[0].Rows)
            {
                ListViewItem lvi = new ListViewItem();
                lvi.Text = row["user_id"].ToString();
                lvi.SubItems.Add(row["user_password"].ToString());
                lvi.SubItems.Add(row["user_name"].ToString());
                lvi.SubItems.Add(row["user_point"].ToString());
                lvi.SubItems.Add(row["use_device"].ToString());
                lvi.SubItems.Add(row["use_device_id"].ToString());
                lvi.SubItems.Add(row["use_app"].ToString());                
                listView1.Items.Add(lvi);
            }
            listView1.EndUpdate();
        }

        void listViewUpdate()
        {
            int max_update_cnt = 10;            
            string user_id = string.Empty;           
            uint user_point = 0;
            string use_app = string.Empty;

            for(int nIdx =0; nIdx < max_update_cnt; nIdx++)
            {
                if (use_device_id_q.Count == 0) break;

                stQueueObject stqueue = new stQueueObject();
                stqueue = use_device_id_q.Dequeue();
                if(stqueue.select_dev_or_app == 0)
                {
                    foreach (DataRow row in sqlite.SelectDetail("user", "user_id, user_point, use_app", $@"use_device_id = {stqueue.id} and use_device =1").Tables[0].Rows)
                    {
                        user_id = row["user_id"].ToString();
                        user_point = uint.Parse(row["user_point"].ToString());      
                        use_app = row["use_app"].ToString();
                        if(use_app == "1")
                        {
                            if (user_point > 0) user_point -= 1;
                            sqlite.Update("user", $"user_point ={user_point.ToString()} ", $"user_id ='{user_id}'");

                            Invoke(new Action(() =>
                            {
                                string messageToSend = user_id + '|' + stqueue.id.ToString() + '|' + user_point.ToString() + '|' + stqueue.sLock.ToString() + '|' + stqueue.gpsLat + '|' + stqueue.gpsLong;

                                client.Publish("RO_PY_t1_JIAjoa_OUT_P_A", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                                rtbxSendPC_App.AppendText(messageToSend + "\n");
                                rtbxSendPC_App.ScrollToCaret();
                            }));
                        }
                    }
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            btnStart_Click(new object() , new EventArgs());
            sqlite = new SQLite();
            listView1.View = View.Details;
            listView1.Columns.Add("user_id", 120, HorizontalAlignment.Left);
            listView1.Columns.Add("user_password", 120, HorizontalAlignment.Left);
            listView1.Columns.Add("user_name", 120, HorizontalAlignment.Left);
            listView1.Columns.Add("user_point", 120, HorizontalAlignment.Left);
            listView1.Columns.Add("use_device", 120, HorizontalAlignment.Left);
            listView1.Columns.Add("use_device_id", 120, HorizontalAlignment.Left);
            listView1.Columns.Add("use_app", 120, HorizontalAlignment.Left);            

            listViewSelect();

            arrGPS.Add("$GPGGA,141113.999,3730.0308,N,12655.2369,E,1,06,1.7,98.9,M,,,,0000*3E");
            //arrGPS.Add("$GPGSA,A,3,02,07,01,20,04,13,,,,,,,3.7,1.7,3.2 * 31");
            //arrGPS.Add("$GPRMC,141113.999,A,3730.0308,N,12655.2369,E,19.77,195.23,101200,,*3C");
            arrGPS.Add("$GPGGA,141114.999,3730.0264,N,12655.2351,E,1,07,1.2,98.8,M,,,,0000 * 3C");
            //arrGPS.Add("$GPGSA,A,3,02,07,01,20,24,04,13,,,,,,2.3,1.2,1.9 * 3E");
            //arrGPS.Add("$GPRMC,141114.999,A,3730.0264,N,12655.2351,E,15.51,202.12,101200,,*3C");
            arrGPS.Add("$GPGGA,141115.999,3730.0231,N,12655.2345,E,1,07,1.2,98.7,M,,,,0000 * 37");
            //arrGPS.Add("$GPGSA,A,3,02,07,01,20,24,04,13,,,,,,2.3,1.2,1.9 * 3E");
            //arrGPS.Add("$GPGSV,2,1,07,07,84,025,47,04,51,289,48,20,40,048,47,02,32,203,46 * 74");
            //arrGPS.Add("$GPGSV,2,2,07,01,23,101,47,13,20,131,32,24,19,268,40 * 49");
            //arrGPS.Add("$GPRMC,141115.999,A,3730.0231,N,12655.2345,E,12.14,194.75,101200,,*33");
            arrGPS.Add("$GPGGA,141116.999,3730.0210,N,12655.2330,E,1,07,1.2,98.5,M,,,,0000 * 37");
            //arrGPS.Add("$GPGSA,A,3,02,07,01,20,24,04,13,,,,,,2.3,1.2,1.9 * 3E");
            //arrGPS.Add("$GPRMC,141116.999,A,3730.0210,N,12655.2330,E,8.01,194.65,101200,,*0F");
            arrGPS.Add("$GPGGA,141117.998,3730.0199,N,12655.2320,E,1,06,1.3,98.2,M,,,,0000 * 33");
            //arrGPS.Add("$GPGSA,A,3,02,07,01,20,24,04,,,,,,,2.4,1.3,2.0 * 30");

            //for (int nIdx = 0; nIdx < 100000; nIdx++)
            //{
            //    strTopicArray[nIdx] = "RO_PY_t1_JIAjoa_OUT_D_" + nIdx.ToString().PadLeft(5, '0') + "_P";
            //    strQosArray[nIdx] = MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE;
            //}

            //for (int nIdx = 100000; nIdx < 200000; nIdx++)
            //{
            //    strTopicArray[nIdx] = "RO_PY_t1_JIAjoa_OUT_A_" + (nIdx - 100000).ToString().PadLeft(5, '0') + "_P";
            //    strQosArray[nIdx] = MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE;
            //}

        }

        private void btnMotorStop_Click(object sender, EventArgs e)
        {
            Invoke(new Action(() =>
            {
                string messageToSend = "14||0|0";

                client.Publish("RO_PY_t1_JIAjoa_OUT_P_D", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);

                rtbxSendPC_Arduino.AppendText(messageToSend + "\n");
                rtbxSendPC_Arduino.ScrollToCaret();
            }));
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            listViewUpdate();
            listViewSelect();
        }

        private void btnSelect_Click(object sender, EventArgs e)
        {
            listViewSelect();
        }

        private void btnTest_Click(object sender, EventArgs e)
        {
            if (bIsTest == false)
                strTestLock = "0";
            else
                strTestLock = "1";
            bIsTest = true;

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if(bIsTest)
            {
                //RO_PY_t1_JIAjoa_OUT_D_P
                // Arduino -> PC (  Device_ID | APP_ID | Lock Sensor | Alarm | GPS_Lat (위도) | GPS_Long (경도)  )
                Invoke(new Action(() =>
                {
                    string messageToSend = "14|junha123|" + strTestLock + "|" + "0" + "|" + "37.057597685699825" + "|" + "127.0795215042016";

                    client.Publish("RO_PY_t1_JIAjoa_OUT_D_P", Encoding.UTF8.GetBytes(messageToSend), MqttMsgBase.QOS_LEVEL_AT_MOST_ONCE, false);
                }));
            }
        }
    }
}

